package fit.iuh.edu.vn.homepage_service;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HomepageServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(HomepageServiceApplication.class, args);
	}

}
